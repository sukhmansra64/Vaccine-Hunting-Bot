require('dotenv').config(); //imports discord bot token as an object

const {Client} = require('discord.js'); //idk what this does lmaooooo
const client = new Client(); //makes a client object

client.on('ready',() =>{ //uses an event listener to see if bot is online
    console.log(`${client.user.tag} has logged in.`);
});

client.on('message',(message)=>{ //event listener to read messages
    console.log(`[${message.author.tag}]: ${message.content}`);
    if(message.content.includes('-pokes')){
        message.channel.send(message.content.substr(6));
    }
});

client.login(process.env.DISCORDJS_BOT_TOKEN); //makes the bot login 